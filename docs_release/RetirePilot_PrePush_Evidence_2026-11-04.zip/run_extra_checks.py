import os,json,sys,csv,re,hashlib
from pathlib import Path
from copy import deepcopy
sys.path.insert(0,'/mnt/data/rp_git_import_v27')
from fastapi.testclient import TestClient
from retirepilot.api import app
from retirepilot.cpf_retirement_v26 import transition_at_55,cpf_life_official_table_2026,CPFUnsupportedCase
from retirepilot.priority_scenarios_v27 import preview_priority_scenario,PRIORITY_STATUS
from retirepilot.local_vault_v24 import LocalVault,VaultError
from cryptography.fernet import Fernet
import tempfile
root=Path('/mnt/data/rp_git_import_v27')
out={'executed_on':'2026-11-04','source':'local v2.7 source tree, read-only probes','checks':[]}
def check(name,condition,detail):
 out['checks'].append({'name':name,'pass':bool(condition),'detail':detail})
 if not condition:print('FAILED',name,detail)

# Bounded CPF examples from current CPF official pages; external reviewer still required.
a=transition_at_55(dob='1971-04-11',as_of='2026-04-11',oa='140000',sa='120000',ma='40000',cpf_membership_confirmed=True)
check('CPF 2026 FRS and SA-first RA transfer',a['frs']=='220400' and a['closing']['RA']=='220400' and a['transfers']['SA_to_RA']=='120000' and a['transfers']['OA_to_RA']=='100400',a['transfers'])
check('CPF SA closes and excess OA preserved',a['closing']['SA']=='0' and a['closing']['OA']=='39600',a['closing'])
a2=transition_at_55(dob='1972-10-05',as_of='2027-10-05',oa='50000',sa='45000',ma='12000',cpf_membership_confirmed=True)
check('CPF 2027 bounded cohort FRS',a2['frs']=='228200' and a2['below_FRS'] is True and a2['closing']['RA']=='95000',a2['closing'])
case=cpf_life_official_table_2026(ra_age55='220400',payout_start_age=65)
check('CPF LIFE published illustration only',case['illustrative_monthly_SGD']=='1780' and case['status']=='published_illustration_not_personal_estimate',case['status'])
try:
 cpf_life_official_table_2026(ra_age55='220401',payout_start_age=65)
 check('CPF LIFE non-table estimate explicitly rejected',False,'unexpected success')
except CPFUnsupportedCase:
 check('CPF LIFE non-table estimate explicitly rejected',True,'no interpolation')

cases={
 'S020':{'cpf_refund_source':'member_transcribed_official_cpf_property_refund','sale_price':'800000','sale_costs':'15000','outstanding_mortgage':'250000','cpf_refund_official':'300000','replacement_home_total_cost':'180000'},
 'S030':{'estimate_source':'member_transcribed_official_cpf_estimate','official_monthly_at_65':'1780','official_monthly_at_70':'2380'},
 'S004':{'current_net_earned_cash_monthly':'6500','part_time_net_earned_cash_monthly':'3000','months':12},
 'S016':{'additional_care_cost_monthly':'1200','months':12},
 'S012':{}
}
for sid,p in cases.items():
 result=preview_priority_scenario(sid,p)
 check(f'{sid} priority event never posts to core forecast',result['may_post_to_household_projection'] is False and result['implemented_as']=='bounded_preview_not_full_event',result['status'])
check('Divorce never makes entitlement claims',preview_priority_scenario('S012',{})['status'].startswith('BLOCKED'), 'legal/consent blocker')

profile=json.loads((root/'data/mixed_income_household.json').read_text())
check('Existing demo profile clearly synthetic',str(profile.get('id','')).startswith('RP-SYNTH-'),profile.get('id'))
client=TestClient(app)
p2=deepcopy(profile)
p2['id']='RP-SYNTH-FAKE-USER'
p2['undocumented_user_input']='FAKE EXAMPLE ONLY. This field is not in the expected profile schema.'
r=client.post('/api/evaluate',json={'profile':p2,'years':1})
# This is a NEGATIVE security test. Success status 200 exposes inadequacy of the prefix gate.
check('Synthetic-ID prefix can pass without independent origin proof',r.status_code==200,{'status_code':r.status_code,'interpretation':'This is a SECURITY FINDING, not an approved control'})
check('API lacks authentication on evaluation route',r.status_code!=401,{'status_code':r.status_code,'interpretation':'This is a SECURITY FINDING, not a passed authorization gate'})
with tempfile.TemporaryDirectory() as d:
 v=LocalVault(Path(d)/'synthetic.sqlite',key=Fernet.generate_key())
 try:
  v.share_household_records('RP-SYNTH-FAKE-USER','P2',identity_evidence='claim',consent_evidence='claim')
  check('Adult sharing fail closed',False,'unblocked sharing')
 except VaultError:
  check('Adult sharing fail closed',True,'no verified identity provider, so sharing is blocked')
 finally: v.close()

rows=list(csv.DictReader((root/'audit/research_slots.csv').open()))
check('48 slots recorded, no sessions claimed',len(rows)==48 and all(x['interview_status']=='Not conducted' for x in rows),{'slots':len(rows),'completed':sum(x['interview_status']=='Completed' for x in rows)})

# Hygiene scan: structural, not a substitute for secret scanning or external security review
files=[p for p in root.rglob('*') if p.is_file() and '.pytest_cache' not in p.parts and '__pycache__' not in p.parts and '.venv' not in p.parts and p.suffix in ('.py','.json','.md','.txt','.yml','.yaml','.csv','.html')]
rx=re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\bsk-proj-[A-Za-z0-9_-]{20,}|\bghp_[A-Za-z0-9]{36}\b')
found=[]
for p in files:
 try:s=p.read_text(encoding='utf-8')
 except:continue
 if rx.search(s):found.append(str(p.relative_to(root)))
check('Heuristic scan found no hardcoded credential patterns',not found,{'scanned_text_files':len(files),'findings':found,'limitation':'Not exhaustive, no live security audit'})

out['count']=len(out['checks'])
out['all_probe_conditions_passed']=all(x['pass'] for x in out['checks'])
out['critical_observations']=[
 'Pass of synthetic-ID prefix probe documents spoofability, not security readiness.',
 'Passing published CPF examples does not prove contribution, interest, account-transition and CPF LIFE lifetime modelling.',
 'The 48-slot register represents planned recruitment only, zero participant evidence.',
 'All five priority scenarios are previews/blocked, not full integrated household life-event engines.'
]
Path('/mnt/data/RetirePilot_PrePush_Review_2026-11-04/prepush_probes.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'checks':len(out['checks']),'conditions_passed':sum(x['pass'] for x in out['checks']),'security_findings':['no API auth','spoofable synthetic ID'],'research_sessions_completed':0},indent=2))
